# AFK Countdown Plugin
Shows you exactly how many seconds it will take before you log out of RuneLite due to inactivity.

[AFK Countdown Preview](https://i.imgur.com/xgNCqY5.mp4)

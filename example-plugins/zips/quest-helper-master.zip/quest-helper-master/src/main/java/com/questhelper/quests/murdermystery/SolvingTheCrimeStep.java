package com.questhelper.quests.murdermystery;

import com.questhelper.questhelpers.QuestHelper;
import com.questhelper.steps.ConditionalStep;
import com.questhelper.steps.QuestStep;

public class SolvingTheCrimeStep extends ConditionalStep
{
	public SolvingTheCrimeStep(QuestHelper questHelper, QuestStep step)
	{
		super(questHelper, step);
		setupConditions();
		setupItemRequirements();
		setupSteps();
	}

	public void setupConditions() {

	}

	public void setupItemRequirements() {

	}

	public void setupSteps()
	{

	}
}

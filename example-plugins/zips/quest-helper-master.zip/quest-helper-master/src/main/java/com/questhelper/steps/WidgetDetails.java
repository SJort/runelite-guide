package com.questhelper.steps;

import lombok.Value;

@Value
public class WidgetDetails
{
	public int groupID;
	public int childID;
	public int childChildID;
}

# Menu Swapper Extended
An external hub for extra menu swapper additions that wouldn't normally make it into Runelite master.

To add your own swaps, fork my repository and create a pull request against the master branch.

Extra swaps should still follow [Jagex rules](https://oldschool.runescape.wiki/w/Update:Another_Message_About_Unofficial_Clients) and not go against the spirit of the game.